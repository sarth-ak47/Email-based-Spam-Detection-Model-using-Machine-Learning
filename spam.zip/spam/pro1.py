import streamlit as st
import joblib
import nltk
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.corpus import stopwords
nltk.download('stopwords')

# Load the vectorizer and model
vectorizer = joblib.load("spam/vectorizer.pkl")
model = joblib.load("spam/spam_model.pkl")


# App configuration
st.set_page_config(page_title="Spam Detector", layout="centered", page_icon="📩")

# Sidebar controls
st.sidebar.title("🔧 Settings")

theme = st.sidebar.radio("Choose Theme", ["Light", "Dark"], index=0)
threshold = st.sidebar.slider("Confidence Threshold", 0.0, 1.0, 0.5, step=0.05)

# Apply dark theme (CSS override)
# Apply dark theme (CSS override)
if theme == "Dark":
    st.markdown("""
        <style>
            html, body, [data-testid="stAppViewContainer"], [data-testid="stAppViewBlockContainer"] {
                background-color: #0e1117;
                color: white;
            }

            /* Sidebar */
            [data-testid="stSidebar"] {
                background-color: #1e1e1e;
                color: white;
            }

            /* All widget text */
            label, div, span, input, textarea, select, button {
                color: white !important;
            }

            /* Input areas */
            .stTextInput > div > div > input,
            .stTextArea > div > textarea,
            .stFileUploader,
            .stSlider {
                background-color: #262730;
                color: white;
            }

            /* Buttons */
            .stButton > button {
                background-color: #404040;
                color: white;
            }

            /* Radio buttons & checkboxes */
            .stRadio label,
            .stCheckbox label {
                color: white !important;
            }

            /* Dataframe / tables */
            .stDataFrame, .css-1d391kg {
                background-color: #1e1e1e !important;
                color: white !important;
            }

            /* Markdown headers */
            h1, h2, h3, h4, h5, h6 {
                color: white !important;
            }

            /* Make typed text in text input/textarea black with white background */
            .stTextInput input,
            .stTextArea textarea {
                color: black !important;
                background-color: white !important;
            }
        </style>
    """, unsafe_allow_html=True)



# App title
st.title("📩 SMS/Email Spam Detector")
st.markdown("🔎 Paste a message or upload a file to check if it's spam or ham.")

# Input section
input_mode = st.radio("Select Input Method", ["📄 Enter Text", "📁 Upload File"])

if input_mode == "📄 Enter Text":
    user_text = st.text_area("Enter your message below:", height=150)
elif input_mode == "📁 Upload File":
    uploaded_file = st.file_uploader("Upload a .txt or .csv file", type=["txt", "csv"])
    user_text = None

# History storage
if "history" not in st.session_state:
    st.session_state.history = []

def predict_spam(text):
    vec = vectorizer.transform([text])
    prob = model.predict_proba(vec)[0][1]
    prediction = "Spam" if prob >= threshold else "Ham"
    return prediction, prob

def show_result(prediction, prob):
    st.subheader(f"🔍 Prediction: {prediction}")
    st.write(f"📈 Probability of Spam: `{prob:.2f}`")
    
    # Pie chart
    fig, ax = plt.subplots()
    ax.pie([prob, 1 - prob], labels=["Spam", "Ham"], colors=["red", "green"],
           autopct='%1.1f%%', startangle=90)
    ax.axis("equal")
    st.pyplot(fig)

# Prediction trigger
if st.button("🔍 Analyze"):
    if input_mode == "📄 Enter Text":
        if user_text.strip() == "":
            st.warning("Please enter a message to analyze.")
        else:
            prediction, prob = predict_spam(user_text)
            show_result(prediction, prob)
            st.session_state.history.append((user_text, prediction, prob))
    else:
        if uploaded_file is not None:
            if uploaded_file.name.endswith(".txt"):
                lines = uploaded_file.read().decode("utf-8").splitlines()
                df = pd.DataFrame(lines, columns=["Message"])
            elif uploaded_file.name.endswith(".csv"):
                df = pd.read_csv(uploaded_file)
                df.columns = ["Message"] if len(df.columns) == 1 else df.columns

            df["Prediction"], df["Probability"] = zip(*df["Message"].apply(predict_spam))
            st.write("📊 Batch Results:")
            st.dataframe(df)
        else:
            st.warning("Please upload a file to analyze.")

# History section
if st.toggle("📜 Show Prediction History"):

    if st.session_state.history:
        history_df = pd.DataFrame(st.session_state.history, columns=["Message", "Prediction", "Probability"])
        st.dataframe(history_df)
    else:
        st.info("No predictions yet.")

# Footer
st.markdown("---")
st.markdown("🚀 Developed with ❤️ using Streamlit")

